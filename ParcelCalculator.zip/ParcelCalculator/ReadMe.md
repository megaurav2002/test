# Parcel Calculator
This is a Console App written in C# and .Net Framework version is 4.6.

## Running the application

1. Open a command prompt as an admin
2. Navigate to the folder where you have copy the project to and then bin/debug folder.
3. Run ParcelCalculator.exe
```
ParcelCalculator.exe
```

## Running the tests 
Tests can be triggered from visual studio. 

## Assumptions
I made some assumptions in the development of the application

- I used type double for the rate and the price. But I assume that weight, height, width and depth are all integer.

## Design Decisions
- I have kept all the important values for calculation business rules in the config file, so it can be easily modified. 
- I have created Calculator class and ICalculator interface, so that the business rules for calculation can be separated from the parcel object, also it can be easily extended to another Calculator class. 
- I have taken out the output messages to a separate class, so that if it is required in the future, we can extend it to an content retrieval service.
- The logging i used is just to writing to Event Logs, but can be extended to other logging services: log4net, etc

## Enhancements
Given more time, I would make the following enhancements
- Unit tests: the unit test coverage is not great.
- Would like to build in web app and run in docker. 