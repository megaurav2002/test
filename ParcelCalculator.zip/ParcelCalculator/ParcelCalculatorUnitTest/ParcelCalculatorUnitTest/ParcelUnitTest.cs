﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ParcelCalculator;

namespace ParcelCalculatorUnitTest
{
    [TestClass]
    public class ParcelUnitTest
    {
        [TestMethod]
        public void ValidateParcelInput_TheNumberOfTheInputIsIncorrect_ReturnError()
        {
            //Arrange
            string userInput = "3,4,5,6,6,6,6";
            var validationResult = new ParcelPropertiesValidationResult();

            Parcel parcel = new Parcel();

            // Act
            validationResult = parcel.ValidateParcelInput(userInput);

            // Assert
            Assert.AreEqual(validationResult.IsValid, false);
            Assert.AreEqual(validationResult.InvalidRason, OutputMessage.InvalidNumberOfInputMsg);
        }

        [TestMethod]
        public void ValidateParcelInput_IncorrectNumberFormat_ReturnError()
        {
            //Arrange
            string userInput = "3,4,wrongFormat,6";
            var validationResult = new ParcelPropertiesValidationResult();

            Parcel parcel = new Parcel();

            // Act
            validationResult = parcel.ValidateParcelInput(userInput);

            // Assert
            Assert.AreEqual(validationResult.IsValid, false);
            Assert.AreEqual(validationResult.InvalidRason, OutputMessage.ConvertToIntErrorMsg);
        }

        [TestMethod]
        public void ValidateParcelInput_ValidUserInput_ReturnValid()
        {
            //Arrange
            string userInput = "3,4,3,6";
            var validationResult = new ParcelPropertiesValidationResult();

            Parcel parcel = new Parcel();

            // Act
            validationResult = parcel.ValidateParcelInput(userInput);

            // Assert
            Assert.AreEqual(validationResult.IsValid, true);
        }
    }
}
