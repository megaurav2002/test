﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ParcelCalculator;

namespace ParcelCalculatorUnitTest
{
    [TestClass]
    public class CalculatorUnitTest
    {
        CalculatorRuleParams calParams = new CalculatorRuleParams();
        ILogging logging = new EventLogLogging("Application", "ParcelCalculator");

        [TestMethod]
        public void SetParcelTypeAndRate_OverWeigtedParcelType_CorrectSet()
        {
            //Arrange
            calParams.MaxAllowedWeight = 50;
            Calculator cal = new Calculator(calParams, logging);

            Parcel parcel = new Parcel();
            parcel.Weight = 100;

            // Act
            cal.SetParcelTypeAndRate(parcel);

            // Assert
            Assert.AreEqual(parcel.TypeOfTheParcel, ParcelType.OverWeighted);
        }

        [TestMethod]
        public void SetParcelTypeAndRate_HeavyParcelType_CorrectSet()
        {
            //Arrange
            calParams.MaxAllowedWeight = 50;
            calParams.MaxWeightForVolumeCalculator = 10;
            calParams.HeavyParcelRate = 15;

            Calculator cal = new Calculator(calParams, logging);
            Parcel parcel = new Parcel();
            parcel.Weight = 20;


            // Act
            cal.SetParcelTypeAndRate(parcel);

            // Assert
            Assert.AreEqual(parcel.TypeOfTheParcel, ParcelType.Heavy);
            Assert.AreEqual(parcel.Rate, calParams.HeavyParcelRate);
        }

        [TestMethod]
        public void SetParcelTypeAndRate_LargeParcelType_CorrectSet()
        {
            //Arrange
            calParams.MaxAllowedWeight = 50;
            calParams.MaxWeightForVolumeCalculator = 10;
            calParams.LargeParcelRate = 0.03;
            calParams.MinVolumeForLargeParcel = 2500;
            Calculator cal = new Calculator(calParams, logging);
            Parcel parcel = new Parcel();
            parcel.Weight = 5;
            parcel.Volume = 3000;

            // Act
            cal.SetParcelTypeAndRate(parcel);

            // Assert
            Assert.AreEqual(parcel.TypeOfTheParcel, ParcelType.Large);
            Assert.AreEqual(parcel.Rate, calParams.LargeParcelRate);
        }

        [TestMethod]
        public void SetParcelTypeAndRate_MediumParcelType_CorrectSet()
        {
            //Arrange
            calParams.MaxAllowedWeight = 50;
            calParams.MaxWeightForVolumeCalculator = 10;
            calParams.MediumParcelRate = 0.04;
            calParams.MinVolumeForLargeParcel = 2500;
            calParams.MinVolumeForMediumParcel = 1500;
            Calculator cal = new Calculator(calParams, logging);
            Parcel parcel = new Parcel();
            parcel.Weight = 5;
            parcel.Volume = 2000;

            // Act
            cal.SetParcelTypeAndRate(parcel);

            // Assert
            Assert.AreEqual(parcel.TypeOfTheParcel, ParcelType.Medium);
            Assert.AreEqual(parcel.Rate, calParams.MediumParcelRate);
        }

        [TestMethod]
        public void SetParcelTypeAndRate_SmallParcelType_CorrectSet()
        {
            //Arrange
            calParams.MaxAllowedWeight = 50;
            calParams.MaxWeightForVolumeCalculator = 10;
            calParams.SmallParcelRate = 0.05;
            calParams.MinVolumeForLargeParcel = 2500;
            calParams.MinVolumeForMediumParcel = 1500;
            Calculator cal = new Calculator(calParams, logging);
            Parcel parcel = new Parcel();
            parcel.Weight = 5;
            parcel.Volume = 1000;

            // Act
            cal.SetParcelTypeAndRate(parcel);

            // Assert
            Assert.AreEqual(parcel.TypeOfTheParcel, ParcelType.Small);
            Assert.AreEqual(parcel.Rate, calParams.SmallParcelRate);
        }

        [TestMethod]
        public void SetParcelTypeAndRate_NullParcel_ThrowException()
        {
            // Arrange
            Calculator cal = new Calculator(calParams, logging);
            Parcel parcel = new Parcel();

            try
            {
                // Act
                cal.SetParcelTypeAndRate(parcel);

                // Assert
                Assert.Fail();
            }
            catch (Exception ex)
            {
                // Assert
                Assert.IsTrue(true);
            }
        }

        [TestMethod]
        public void CalculatePrice_OverWeigtedParcel_CorrectCalculationResult()
        {
            // Arrange
            Calculator cal = new Calculator(calParams, logging);
            Parcel parcel = new Parcel();
            parcel.TypeOfTheParcel = ParcelType.OverWeighted;

            // Act
            CalculationResult result = cal.CalculatePrice(parcel);

            // Assert
            Assert.IsTrue(result.IsOverWeighted);
        }

        [TestMethod]
        public void CalculatePrice_HeavyParcel_CorrectCalculationResult()
        {
            // Arrange
            Calculator cal = new Calculator(calParams, logging);
            Parcel parcel = new Parcel();
            parcel.TypeOfTheParcel = ParcelType.Heavy;
            parcel.Weight = 20;
            parcel.Rate = 15;

            // Act
            CalculationResult result = cal.CalculatePrice(parcel);

            // Assert
            Assert.IsTrue(result.IsSuccessful);
            Assert.AreEqual(result.Price, 20*15);
        }

        [TestMethod]
        public void CalculatePrice_LargeParcel_CorrectCalculationResult()
        {
            // Arrange
            Calculator cal = new Calculator(calParams, logging);
            Parcel parcel = new Parcel();
            parcel.TypeOfTheParcel = ParcelType.Large;
            parcel.Volume = 300;
            parcel.Rate = 0.03;
            
            // Act
            CalculationResult result = cal.CalculatePrice(parcel);

            // Assert
            Assert.IsTrue(result.IsSuccessful);
            Assert.AreEqual(result.Price, parcel.Volume * parcel.Rate);
        }

        [TestMethod]
        public void CalculatePrice_NullParcel_ThrowException()
        {
            // Arrange
            Calculator cal = new Calculator(calParams, logging);
            Parcel parcel = new Parcel();

            // Act
            try
            {
                CalculationResult result = cal.CalculatePrice(parcel);

                // Assert
                Assert.Fail();
            }
            catch (Exception ex)
            {
                // Assert
                Assert.IsTrue(true);   
            }
        }
    }
}
