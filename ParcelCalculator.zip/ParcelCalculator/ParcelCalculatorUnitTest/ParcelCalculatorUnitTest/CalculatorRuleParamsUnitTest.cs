﻿using System;
using System.Collections.Specialized;
using System.Configuration;
using System.Reflection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ParcelCalculator;

namespace ParcelCalculatorUnitTest
{
    [TestClass]
    public class CalculatorRuleParamsUnitTest
    {
        readonly ILogging logging = new EventLogLogging("Application", "ParcelCalculator");
        NameValueCollection applicationSettings = new NameValueCollection(){
            { "maxAllowedWeight", "50" },
            { "maxWeightForVolumeCalculator", "10" },
            { "minVolumeForMediumParcel", "1500" },
            { "minVolumeForLargeParcel", "2500" },
            { "heavyParcelRate", "15" },
            { "smallParcelRate", "0.05" },
            { "mediumParcelRate", "0.04" },
            { "largeParcelRate", "0.03" }
        };

        [TestMethod]
        public void GetValueForParam_KeyValueExistAndValueCanBeConvertToDouble_ReturnValue()
        {
            // Arrange
            NameValueCollection settings = new NameValueCollection(applicationSettings);

            // Act
            try
            {
                var calculatorRuleParams = new CalculatorRuleParams(logging, applicationSettings);

                // Assert
                Assert.IsTrue(true);
                
            }
            catch (Exception ex)
            {
                // Assert
                Assert.Fail();
            }
        }

        [TestMethod]
        public void GetValueForParam_KeyValueExistAndValueCanNotBeConvertToDouble_ThrowException()
        {
            // Arrange
            NameValueCollection settings = new NameValueCollection(applicationSettings);
            settings["maxAllowedWeight"] = "wrongFormat";

            // Act
            try
            {
                var calculatorRuleParams = new CalculatorRuleParams(logging, applicationSettings);

                // Assert
                Assert.Fail();
            }
            catch (Exception ex)
            {
                // Assert
                Assert.IsTrue(true);   
            }
        }

        [TestMethod]
        public void GetValueForParam_KeyDoesNotExistInTheCollection_ThrowExeption()
        {
            // Arrange
            // Arrange
            NameValueCollection settings = new NameValueCollection(applicationSettings);
            settings.Remove("maxAllowedWeight");

            // Act
            try
            {
                var calculatorRuleParams = new CalculatorRuleParams(logging, settings);

                // Assert
                Assert.Fail();
            }
            catch (Exception ex)
            {
                // Assert
                Assert.IsTrue(true);
            }
        }
    }
}
