﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParcelCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            ILogging logging = new EventLogLogging("Application", "ParcelCalculator");

            try
            {
                CalculatorRuleParams calParams = new CalculatorRuleParams(logging, ConfigurationManager.AppSettings);
                Calculator calculator = new Calculator(calParams, logging);

                var result = new CalculationResult();
                var parcel = new Parcel();

                //input
                Console.WriteLine("Please provide the parcel weight, height, width, depth and seperated by , ");
                string inputValue = Console.ReadLine();

                //System.Diagnostics.Debugger.Launch();
                ParcelPropertiesValidationResult parcelValidationResult = parcel.ValidateParcelInput(inputValue);

                if (!parcelValidationResult.IsValid)
                {
                    Console.WriteLine(parcelValidationResult.InvalidRason);
                }
                else
                {
                    parcel.SetPropertiesForUserInput(inputValue);
                    parcel.SetCalculator(calculator);

                    result = parcel.GetPrice();

                    if (result.IsOverWeighted && result.IsSuccessful)
                    {
                        Console.WriteLine(string.Format(OutputMessage.ParcelTypeMsg, parcel.TypeOfTheParcel.ToString()));
                        Console.WriteLine(OutputMessage.RejectMsg);
                    }
                    else if (!result.IsOverWeighted && result.IsSuccessful)
                    {
                        Console.WriteLine(string.Format(OutputMessage.ParcelTypeMsg, parcel.TypeOfTheParcel.ToString()));
                        Console.WriteLine(string.Format(OutputMessage.PriceMsg, result.Price.ToString()));
                    }
                    else
                        Console.WriteLine(OutputMessage.TechnicalErrorMsg);
                }
            }
            catch (Exception ex)
            {
                logging.WriteLog("There is an exception happened during the calculation. Exception Msg: {0}, Inner Exception: {1}", new string[] { ex.Message, ex.InnerException.ToString() });
                Console.WriteLine(OutputMessage.TechnicalErrorMsg);
            }
        }
    }
}
