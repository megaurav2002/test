﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParcelCalculator
{
    public class OutputMessage
    {
        public const string TechnicalErrorMsg = "There is a technical error, please contact admin.";
        public const string ConvertToIntErrorMsg = "Can not convert input to integer.";
        public const string InvalidNumberOfInputMsg = "The number of inputs should be 4.";
        public const string RejectMsg = "Rejected";
        public const string PriceMsg = "The cost is ${0}";
        public const string ParcelTypeMsg = "The type of the parcel is {0}";
    }
}
