﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParcelCalculator
{
    public class Parcel
    {
        private ICalculator _calculator;

        public int Weight { get; set; }
        public int Volume { get; set; }
        public ParcelType TypeOfTheParcel { get; set; }
        public double Rate { get; set; }
        public Parcel() { }
        public Parcel(string userInput, Calculator calculator)
        {
            SetPropertiesForUserInput(userInput);

            _calculator = calculator;
            _calculator.SetParcelTypeAndRate(this);
        }

        public void SetCalculator(Calculator cal)
        {
            _calculator = cal;
            _calculator.SetParcelTypeAndRate(this);
        }
        public CalculationResult GetPrice()
        {
            return _calculator.CalculatePrice(this);
        }

        public ParcelPropertiesValidationResult ValidateParcelInput(string userInput)
        {
            var validationResult = new ParcelPropertiesValidationResult();
            string[] properties = userInput.Split(',');
            if (properties.Count() != 4)
            {
                validationResult.IsValid = false;
                validationResult.InvalidRason = OutputMessage.InvalidNumberOfInputMsg;
            }
            else
            {
                try
                {
                    int[] asIntegers = properties.Select(s => int.Parse(s)).ToArray();

                    validationResult.IsValid = true;
                    validationResult.InvalidRason = "";
                }
                catch (Exception ex)
                {
                    validationResult.IsValid = false;
                    validationResult.InvalidRason = OutputMessage.ConvertToIntErrorMsg;
                }
            }
            return validationResult;
        }
        public void SetPropertiesForUserInput(string userInput)
        {
            //weight, height, width, depth
            string[] properties = userInput.Split(',');

            int[] asIntegers = properties.Select(s => int.Parse(s)).ToArray();
            this.Weight = asIntegers[0];
            this.Volume = asIntegers[1] * asIntegers[2] * asIntegers[3];
        }
    }
}
